package test
import fp.ReturnFunction
import org.scalatest.FunSuite

class cool extends FunSuite {

 test("apple"){
      val adder = ReturnFunction.strangeAddition(5)
      assert(adder(3) == 8)
    }

}