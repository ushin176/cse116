package fp

object ReturnFunction {

  def strangeAddition(intakeNum: Int): Int => Int = {
    (a: Int) => a + intakeNum
  }

}
