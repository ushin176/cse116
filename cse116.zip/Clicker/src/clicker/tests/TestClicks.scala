package clicker.tests

import akka.actor.{ActorSystem, Props}
import akka.testkit.{ImplicitSender, TestKit}
import clicker._
import clicker.database.DatabaseActor
import clicker.model.GameActor
import org.scalatest.{BeforeAndAfterAll, Matchers, WordSpecLike}
import play.api.libs.json.Json

import scala.concurrent.duration._

class TestClicks extends TestKit(ActorSystem("TestClicks"))
  with ImplicitSender
  with WordSpecLike
  with Matchers
  with BeforeAndAfterAll {

  override def afterAll: Unit = {
    TestKit.shutdownActorSystem(system)
  }


  "A Clicker Game" must {
    "react to user clicks with shovels appropriately" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold
      gameActor ! ClickGold

      // Wait for 50ms to ensure ClickGold messages resolve before moving on
      expectNoMessage(50.millis)

      // Send Update message and expect a GameState message in response
      // Wait up to 100ms for the response
      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      // Parse gameState and use assert to test each value
      // TODO

      val data = Json.parse(gameStateJSON)

      var gold: Double = (data \ "gold").as[Double]

      assert(gold == 2.0)

    }
  }



  "A Clicker Game 1" must {
    "Clicks 1" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold
      gameActor ! ClickGold
      gameActor ! ClickGold
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState

      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == -7.0)
    }
  }

  "A Clicker Game 2" must {
    "Clicks 2" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold
      gameActor ! ClickGold
      gameActor ! ClickGold
      gameActor ! ClickGold
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState

      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == -56.0)
    }
  }

  "A Clicker Game 3" must {
    "Clicks 3" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //6
      gameActor ! ClickGold //7
      gameActor ! ClickGold //8
      gameActor ! ClickGold //9
      gameActor ! ClickGold //10
      gameActor ! BuyEquipment("shovel") // -10

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == 0.0)
    }
  }

  "A Clicker Game 4" must {
    "Clicks 4" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == -5.0)
    }
  }

  "A Clicker Game 5" must {
    "Clicks 5" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //5
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == 0.5)
    }
  }

  "A Clicker Game 6" must {
    "Clicks 6" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == 5.5)
    }
  }

  "A Clicker Game 7" must {
    "Clicks 7" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")
      gameActor ! BuyEquipment("shovel")

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == 2.4749999999999996)
    }
  }

  "A Clicker Game 8" must {
    "Clicks 8" in {

      val database = system.actorOf(Props(classOf[DatabaseActor], "test"))
      val gameActor = system.actorOf(Props(classOf[GameActor], "username", database))

      gameActor ! BuyEquipment("shovel")
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4
      gameActor ! ClickGold //5
      gameActor ! ClickGold //1
      gameActor ! ClickGold //2
      gameActor ! ClickGold //3
      gameActor ! ClickGold //4

      expectNoMessage(50.millis)

      gameActor ! Update
      val gs: GameState = expectMsgType[GameState](400.millis)

      val gameStateJSON: String = gs.gameState


      val json_data = Json.parse(gameStateJSON)

      val gold: Double = (json_data \ "gold").as[Double]

      assert(gold == 8.0)
    }
  }

}