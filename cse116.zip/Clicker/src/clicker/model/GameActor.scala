package clicker.model

import akka.actor.{Actor, ActorRef}
import clicker.{BuyEquipment, ClickGold, GameState, Update}
import play.api.libs.json._



class GameActor(username: String, database: ActorRef) extends Actor {

  //var currentTime: Long = System.nanoTime()  //TODO: Later on you can get the time as a Long

  //TODO: Set gold to 0 but JSON or hard code?

  var gold: Double = 0.0
  var shovels: Int = 0
  var shovelPrice: Double = 10.0

  //var gold: JsValue = Json.parse("""{ "gold": 0 }""")

  override def receive: Receive = {

    case ClickGold =>
      gold += 1

    case BuyEquipment(equipmentId: String) =>
      gold -= shovelPrice
      if((equipmentId == "shovel") && (gold >= 0) && (shovelPrice <= gold)) {
        shovels += 1
        shovelPrice *= 1.05
      }

    case Update =>
      val mappingGold: Map[String, Double] = Map("gold" -> gold) // Literally Jacob told us about what type of map types we have to use Jsvalue
      val strJson = Json.stringify(Json.toJson(mappingGold))
      sender() ! GameState(strJson)
  }

}